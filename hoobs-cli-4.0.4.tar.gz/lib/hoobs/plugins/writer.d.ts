/**************************************************************************************************
 * hoobs-cli                                                                                      *
 * Copyright (C) 2020 HOOBS                                                                       *
 *                                                                                                *
 * This program is free software: you can redistribute it and/or modify                           *
 * it under the terms of the GNU General Public License as published by                           *
 * the Free Software Foundation, either version 3 of the License, or                              *
 * (at your option) any later version.                                                            *
 *                                                                                                *
 * This program is distributed in the hope that it will be useful,                                *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                                 *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                                  *
 * GNU General Public License for more details.                                                   *
 *                                                                                                *
 * You should have received a copy of the GNU General Public License                              *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.                          *
 **************************************************************************************************/
export default class Writer {
    static create(scope: string, name: string, tag: string): Promise<void>;
    static gui(data: {
        [key: string]: any;
    }): void;
    static typescript(data: {
        [key: string]: any;
    }): void;
    static javascript(data: {
        [key: string]: any;
    }): void;
    static schema(data: {
        [key: string]: any;
    }): void;
    static features(): Promise<{
        [key: string]: any;
    }>;
    static license(): Promise<{
        [key: string]: any;
    }>;
    static dependencies(data: {
        [key: string]: any;
    }, dev?: boolean): Promise<void>;
    static package(data: {
        [key: string]: any;
    }): void;
    static nodemon(data: {
        [key: string]: any;
    }): void;
    static eslintrc(data: {
        [key: string]: any;
    }): void;
    static tsconfig(data: {
        [key: string]: any;
    }): void;
    static npmignore(data: {
        [key: string]: any;
    }): void;
    static gitignore(data: {
        [key: string]: any;
    }): void;
}
//# sourceMappingURL=writer.d.ts.map